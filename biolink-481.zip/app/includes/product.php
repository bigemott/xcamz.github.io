<?php
define('PRODUCT_NAME', 'Biolinks');
define('PRODUCT_KEY', 'biolinks');
define('PRODUCT_URL', 'https://altumco.de/phpbiolinks-buy');
define('PRODUCT_DOCUMENTATION_URL', 'https://altumco.de/phpbiolinks-docs');
define('PRODUCT_VERSION', '4.8.1');
define('PRODUCT_CODE', '481');
