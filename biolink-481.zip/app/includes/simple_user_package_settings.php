<?php

return [
    'additional_global_domains',
    'custom_url',
    'deep_links',
    'no_ads',
    'removable_branding',
    'custom_branding',
    'custom_colored_links',
    'statistics',
    'google_analytics',
    'facebook_pixel',
    'custom_backgrounds',
    'verified',
    'scheduling',
    'seo',
    'utm',
    'socials',
    'fonts'
];
