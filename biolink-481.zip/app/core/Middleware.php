<?php

namespace Altum\Middlewares;

class Middleware {


}
