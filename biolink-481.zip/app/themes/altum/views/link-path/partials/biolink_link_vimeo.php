<?php defined('ALTUMCODE') || die() ?>

<div class="my-3 embed-responsive embed-responsive-16by9 link-iframe-round">
    <iframe class="embed-responsive-item" scrolling="no" frameborder="no" src="https://player.vimeo.com/video/<?= $data->embed ?>"></iframe>
</div>

