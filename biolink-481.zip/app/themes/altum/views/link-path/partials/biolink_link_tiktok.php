<?php defined('ALTUMCODE') || die() ?>

<div class="my-3 link-iframe-round">
    <blockquote class="tiktok-embed" data-video-id="<?= $data->embed ?>">
        <section></section>
    </blockquote>

    <script defer src="https://www.tiktok.com/embed.js"></script>
</div>
